#give a 15% raise to an employees salary

previous_salary = float(input("Enter your previous salary: "))

new_salary = previous_salary * 1.15

print("Congratulations! You've received a raise. Your new salary is {:.2f}".format(new_salary))
