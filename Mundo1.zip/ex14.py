#temperature converter

celsius = float(input("Enter current temperature(Celsius): "))

fahrenheit = ((9*celsius) / 5) + 32

print("{} Celsius is equivalent to {} Fahrenheit".format(celsius, fahrenheit))

"""
#other way around

celsius =  (fahrenheit - 32) * 5/9
"""
