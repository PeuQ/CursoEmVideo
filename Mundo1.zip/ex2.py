nome = input("Qual é seu nome?\n")

print("\nBem vindo,", nome, "!")

"""
nome = input("Qual é seu nome?\n")

print("\nBem vindo, {}!".format(nome))
"""
