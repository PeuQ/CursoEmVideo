#Sum of two numbers

num1 = float(input("Enter a number: "))
num2 = float(input("\nEnter another number: "))

sum = num1 + num2

print("\nthe sum is {}".format(sum))

#print("the sum is {}".format(num1 + num2))
