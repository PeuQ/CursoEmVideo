#show the double, triple, and square root of a number

num = float(input("Enter a number: "))

dbl = num * 2

trpl = num * 3

sqrt = num ** 0.5

print("Of {}, the double is {}, the triple is {} and the square root is {}".format(num, dbl, trpl, sqrt))

"""
sqrt = pow(num, 0.5)
"""