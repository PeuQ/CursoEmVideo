#give a 5% discount to a product's price(input)

full_price = float(input("Enter the products price: "))

discount_price = full_price * 0.95

print("Congratulations, you received a 5% discount! your purchase will come at ${:.2f}".format(discount_price))
