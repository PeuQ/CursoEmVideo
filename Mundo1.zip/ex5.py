#predecessor and successor

num = int(input("Enter an integer number: "))

successor = num + 1
predecessor = num - 1

print("The predecessor is {1} and the successor is {0}".format(successor, predecessor))
