#get two grades from a student and take its...

grade1 = float(input("Enter 1º grade: "))
grade2 = float(input("\nEnter 2º grade: "))

med = (grade1 + grade2) / 2

print("The media for the two grades is {}".format(med))
