"""
Program to find if given number is odd or even
"""
num = int(input("Enter a number: "))

if(num % 2 == 0):
  print("Given number is even.")

elif (num % 2 != 0):
  print("Given number is odd.")
