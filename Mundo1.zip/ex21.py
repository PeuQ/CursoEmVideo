#execute a mp3 file. play the audio.

import playsound

playsound.playsound("whatever.mp3")
